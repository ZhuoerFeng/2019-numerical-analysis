#include <bits/stdc++.h>
using namespace std;


float series1(int n) {
    float sum = 0;
    for (int i = 1; i <= n; ++i) {
        sum += (float) (1.0 / i);
    }
    return sum;
}

double series2(long long n) {
    double sum = 0;
    for (long long i = 1; i <= n; ++i) {
        sum += (double) (1.0 / i);
    }
    return sum;
}


int main() {
    long long n;
    scanf("%lld", &n);
    // for (int i = 2097100; i < 2097300; i++) {
    //     printf("%.40f\n", series1(i));
    // }
    cout << "fuck" << n << endl;
    for (long long i = 100000000000000000; i < n; ++i) {
        printf("double: input %I64d, output...  %.100lf\n",i,  1.0 / i);
        // cout << setprecision(30) << i << " ---- " << setprecison() << 1.0 / i << endl;
    }
    return 0;
}